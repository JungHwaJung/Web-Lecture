function over(obj) {
  obj.style;
}
function out(obj) {
  obj.style;
}
